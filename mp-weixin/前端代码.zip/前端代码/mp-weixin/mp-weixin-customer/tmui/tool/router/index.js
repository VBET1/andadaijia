"use strict";
const useTmRouterBefore = (arg) => {
};
const useTmRouterAfter = (arg) => {
};
exports.useTmRouterAfter = useTmRouterAfter;
exports.useTmRouterBefore = useTmRouterBefore;
