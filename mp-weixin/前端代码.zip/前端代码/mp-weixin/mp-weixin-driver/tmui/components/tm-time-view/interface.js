"use strict";
var timeDetailType = /* @__PURE__ */ ((timeDetailType2) => {
  timeDetailType2["year"] = "year";
  timeDetailType2["month"] = "month";
  timeDetailType2["day"] = "date";
  timeDetailType2["hour"] = "hour";
  timeDetailType2["minute"] = "minute";
  timeDetailType2["second"] = "second";
  return timeDetailType2;
})(timeDetailType || {});
exports.timeDetailType = timeDetailType;
